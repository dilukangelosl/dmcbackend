app.config(function($stateProvider,$urlRouterProvider) {
    var helloState = {
        name: 'home',
        url: '/home',
        templateUrl: 'view1/view1.html',
        controller:'View1Ctrl'
    }

    var aboutState = {
        name: 'stats',
        url: '/stats',
        templateUrl: 'view2/view2.html',
        controller:'View2Ctrl'
    }


    $urlRouterProvider
        .otherwise('/home');
    $stateProvider.state(helloState);
    $stateProvider.state(aboutState);
});