'use strict';


app.controller('View2Ctrl', [function() {

}]);